package spartons.com.googlemapspolylineexample.distanceModule;

/**
 * Created by Ahsen Saeed on 5/15/2017.
 */

public class Destination {

    public Distance distance;
    // may want type to be LatLng
    public String location;
}
