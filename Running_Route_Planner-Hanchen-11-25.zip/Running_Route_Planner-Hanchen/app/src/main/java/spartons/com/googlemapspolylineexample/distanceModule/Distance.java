package spartons.com.googlemapspolylineexample.distanceModule;

/**
 * Created by Ahsen Saeed on 5/15/2017.
 */

public class Distance {
    public String text;
    public int value;

    Distance(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
