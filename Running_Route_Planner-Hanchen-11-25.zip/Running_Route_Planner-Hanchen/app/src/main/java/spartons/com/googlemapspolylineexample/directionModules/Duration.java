package spartons.com.googlemapspolylineexample.directionModules;

/**
 * Created by Ahsen Saeed on 5/15/2017.
 */

class Duration {

    private String text;
    private int value;

    Duration(String text, int value) {
        this.text = text;
        this.value = value;
    }
}
